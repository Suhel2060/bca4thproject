function insertbook(e){
    e.preventDefault();
    let ISBN=document.querySelector('#BookId').value;
    let bookname=document.querySelector('#BookId').value;
    let authorname=document.querySelector('#AuthorName').value;
    let publicationname=document.querySelector('#PublicationName').value;
    let catagories=document.querySelector('#catagories').value;
    let image=document.querySelector('#image');
    let description=document.querySelector('#Description').value;
    let quantity=document.querySelector('Quantity').value;
    let form_data=new formdata();
    form_data.append("image",image)
    form_data.append("ISBN",ISBN)
    form_data.append("bookname",bookname)
    form_data.append("authorname",authorname)
    form_data.append("publication",publicationname)
    form_data.append("description",description)
    form_data.append("catagories",catagories)
    form_data.append("description",quantity)
    form_data.append("quantity",quantity)
    fetch("../../phpfile/adminaddbooks.php",{
        method:"POST",
        body: form_data,
    })
    .then(response => response.json())
    .then((data)=>{
        console.log(data);
    })

}